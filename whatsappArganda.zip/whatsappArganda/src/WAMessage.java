
public class WAMessage {
	private String text;
	private Fecha f;
	private Horario h;
	private boolean owned;
	
	public WAMessage() {
		super();
		// TODO Auto-generated constructor stub
	}

	public WAMessage(String text, Fecha f, Horario h, boolean owned) {
		super();
		this.text = text;
		this.f = f;
		this.h = h;
		this.owned = owned;
	}
	

	@Override
	public String toString() {
		return "WAMessage [text=" + text + ", f=" + f + ", h=" + h + ", owned="
				+ owned + "]";
	}
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((f == null) ? 0 : f.hashCode());
		result = prime * result + ((h == null) ? 0 : h.hashCode());
		result = prime * result + (owned ? 1231 : 1237);
		result = prime * result + ((text == null) ? 0 : text.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WAMessage other = (WAMessage) obj;
		if (f == null) {
			if (other.f != null)
				return false;
		} else if (!f.equals(other.f))
			return false;
		if (h == null) {
			if (other.h != null)
				return false;
		} else if (!h.equals(other.h))
			return false;
		if (owned != other.owned)
			return false;
		if (text == null) {
			if (other.text != null)
				return false;
		} else if (!text.equals(other.text))
			return false;
		return true;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Fecha getF() {
		return f;
	}

	public void setF(Fecha f) {
		this.f = f;
	}

	public Horario getH() {
		return h;
	}

	public void setH(Horario h) {
		this.h = h;
	}

	public boolean getOwned() {
		return owned;
	}

	public void setOwned(boolean owned) {
		this.owned = owned;
	}
	
	public Object clone()
	{
		Fecha newF = (Fecha)f.clone();
		Horario newH = (Horario) h.clone();
		return new WAMessage (text, newF, newH,owned);
	}
	
}
