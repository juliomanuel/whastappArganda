import java.util.List;


public class BufferMessage {

	private List<WAMessage> messages;

	public BufferMessage() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BufferMessage(List<WAMessage> messages) {
		super();
		this.messages = messages;
	}

	private String messageToText(int i)
	{
		String textMsg = "";
		if (i==0)
			textMsg += "\t\t\t" + messages.get(0).getF() + "\n\n";
		else 
		{
			Fecha actual = messages.get(i).getF();
			Fecha anterior = messages.get(i-1).getF();
			if (!actual.equals(anterior))
				textMsg += "\t\t\t" + actual + "\n\n";
		}
		if (messages.get(i).getOwned())
			textMsg += "[YO  " + messages.get(i).getText() + "]" + "\n\n";
		else
			textMsg += "[IVAN   " + messages.get(i).getText() + "]" + "\n\n";   

		return textMsg + "\n\n";
	}

	@Override
	public String toString() {
		String res = "";
		for (int i=0; i < this.messages.size(); i++)
			res += messageToText(i);
		return res;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
		+ ((messages == null) ? 0 : messages.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BufferMessage other = (BufferMessage) obj;
		if (messages == null) {
			if (other.messages != null)
				return false;
		} else if (!messages.equals(other.messages))
			return false;
		return true;
	}

	public List<WAMessage> getMessages() {
		return messages;
	}

	public void setMessages(List<WAMessage> messages) {
		this.messages = messages;
	}



}
