import java.util.ArrayList;
import java.util.List;


public class ProgramaWA {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Fecha f1 = new Fecha (1,3,2020);
		Fecha f2 = new Fecha (2,3,2020);
		Horario h11 = new Horario (23,14, 0);
		Horario h12 = new Horario (23,14, 3);
		Horario h13 = new Horario (23,14, 7);
		Horario h14 = new Horario (23,14, 40);
		Horario h15 = new Horario (23,14, 42);
		Horario h21 = new Horario (1,56, 0);
		Horario h22 = new Horario (1,56, 7);

		List<WAMessage> listMsg = new ArrayList<WAMessage>();
		listMsg.add ( 
				new WAMessage ("Tu de qu� vas?",f1,h11,true));
		listMsg.add ( 
				new WAMessage ("Por qu� dices eso?",f1,h12,false));
		listMsg.add (  
				new WAMessage ("Tu ya sabes por qu� lo digo!",f1,h13,true));
		listMsg.add ( 
				new WAMessage ("Espera un momento que me llaman!",f1,h14,false));
		listMsg.add (  
				new WAMessage ("Tu de qu� vas?",f2,h21,true));
		listMsg.add ( 
				new WAMessage ("Qu� le voy a hacer! Me pas� de copas",f2,h22,false));


		BufferMessage bufWA = new BufferMessage (listMsg);
		System.out.println (bufWA);

	}

}
